﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Net.WebSockets;
using System.Text;

namespace NetworkHomeworkServer05._08._2024
{
    
    class client
    {
        public int id;
        public int answ;
        public int count = 0;
        public int clientport;
        public EndPoint endPoint;
       public bool flagnxtq = true;
        public client(int ID, EndPoint endPoint, int port)
        {
            clientport = port;
            id = ID;
            this.endPoint = endPoint;
        }
    }

    class question
    {
        static internal string[] massq = { "1+1", "2+4", "5+5" };
        static internal int[] res = { 2, 6, 10 };
        static internal int num = 0;
    }
    class Udpserver
    {
        public List<client> clients = new List<client>();
        public Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);


       
        public void broadcastq(List<client> clients)
        {
            Thread.Sleep(10);
           
            foreach (client client in clients)
            {
                try
                {
                    if (client.flagnxtq)
                    {

                        socket.SendTo(Encoding.ASCII.GetBytes(question.massq[question.num]), client.endPoint);
                        client.flagnxtq = false;
                    }
                }
                catch
                {
                    Console.WriteLine($"client {client.id} DISCONECT");
                    clients.Remove(client);

                }
            }
            

        }



        public void Start()
        {
            socket.Bind(new IPEndPoint(IPAddress.Any, 80));
        }

        public void messReceive()
        {

            EndPoint remoteEndPoint = new IPEndPoint(IPAddress.Any, 0);
            byte[] buff = new byte[1024];
            string message = "";
            int bytesRead=0;
            int result = 0;

            while (true)
            {
                try //когда клиент прервал соединение и мы пытаемся прочитать данные из сокета выбивается исключение потому что его больше нет
                 {
                    bytesRead = socket.ReceiveFrom(buff, ref remoteEndPoint);
                    if (bytesRead <= 0) break;
                    message = Encoding.ASCII.GetString(buff, 0, bytesRead);

                    if (message == "h")
                    {
                        bool isUnique = true;
                        foreach (client c in clients)
                        {
                            if (c.endPoint.Equals(remoteEndPoint))
                            {
                                isUnique = false;
                                break;
                            }
                        }
                        if (isUnique)
                        {
                            clients.Add(new client(clients.Count, remoteEndPoint, (remoteEndPoint as IPEndPoint).Port));
                            byte[] buffer2 = new byte[1];
                            buffer2[0] = (byte)clients.Count;
                            socket.SendTo(buffer2, remoteEndPoint);
                            Console.WriteLine("сlient connected " + clients.Count);

                        }


                    }

                    else
                    {
                        client currclient = clients.FirstOrDefault(x => x.endPoint.Equals(remoteEndPoint));
                        result = Convert.ToInt32(message);
                        broadcast(message, currclient);
                        if (result == question.res[question.num])
                        {
                            Console.WriteLine($"WIN POINt:{++currclient.count}:currclient ID:{currclient.id}\t IP: {currclient.endPoint.ToString()} reply:{result}");
                            broadcast("WIN", currclient);
                            clients.ForEach(x => x.flagnxtq = true);
                            if (question.num == question.massq.Length - 1)
                            {
                                question.num = 0;
                            }
                            else
                            {
                                question.num++;
                            }

                        }
                        else
                        {
                            Console.WriteLine($"NO:currclient ID:{currclient.id}\t IP: {currclient.endPoint.ToString()} reply:{result}");
                            broadcast("NO", currclient);
                        }
                    }
                } catch {


                    foreach (client x in clients)
                    {
                        if(x.endPoint.Equals(remoteEndPoint))
                        {
                            Console.WriteLine($"client id:{x.id} IP:{x.endPoint.ToString()} disconected");
                            clients.Remove(x);

                        }
                    }
                   

                }

            }


            
        }
        public void broadcast(string s,client curr)
        {
            
                foreach (client client in clients)
                {
                try
                {
                    if (client.id != curr.id)
                    {
                        socket.SendTo(Encoding.ASCII.GetBytes($"Point:{client.count} client id:{curr.id}:" + s), client.endPoint);
                    }
                }
                catch
                {
                    clients.Remove(client);
                    Console.WriteLine($"client {client.id} DISCONECT");
                }
                }
            
          

           
        } // try catch в broadcast мертвый код.
       
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            Udpserver server = new Udpserver();
            server.Start();
           
            
            
                
                while (true)
                {
                    Task.Run(() => server.messReceive());
                    
                    server.broadcastq(server.clients);

                }
            
            

        }
    }
}



