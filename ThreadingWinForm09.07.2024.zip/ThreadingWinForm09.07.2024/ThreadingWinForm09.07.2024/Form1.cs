namespace ThreadingWinForm09._07._2024
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private async void button1_Click(object sender, EventArgs e) 
        {
            //2
            if (Directory.Exists(@"D:\Visual project\ThreadingWinForm09.07.2024\ThreadingWinForm09.07.2024\test"))
            {
                int result =0;
             string[] files = Directory.GetFiles(@"D:\Visual project\ThreadingWinForm09.07.2024\ThreadingWinForm09.07.2024\test","*",SearchOption.AllDirectories);
             foreach(string file in files)
             { 
                result  +=  await func(textBox1, file);
             }
              label2.Text = result.ToString();








            }

            else
            {
                MessageBox.Show("DIRECTORY DOESN`T EXIST");
            }



            //1
           /* int res = await func(textBox1);
            label2.Text = res.ToString();*/


        }




        //2




        public static async Task<int> func(TextBox textBox1,string filename)
        {
            int count = 0;
            using (FileStream f = new FileStream(filename, FileMode.Open, FileAccess.Read))
            {
                using (StreamReader sr = new StreamReader(f))
                {
                    string buff;
                    while (!sr.EndOfStream)
                    {
                        buff = sr.ReadLine();
                        string[] massbuff = buff.Split(new char[] { ' ' });
                        foreach (string line in massbuff)
                        {
                            if (line == textBox1.Text)
                            {
                                count++;
                            }
                        }

                    }
                }
            }
            return count;
        }






        //1
        /* public static async Task<int> func(TextBox textBox1)
         {
             int count = 0;
             using (FileStream f = new FileStream("file.txt", FileMode.Open, FileAccess.Read))
             {
                 using (StreamReader sr = new StreamReader(f))
                 {
                     string buff;
                     while (!sr.EndOfStream)
                     {
                         buff = sr.ReadLine();
                         string[] massbuff = buff.Split(new char[] { ' ' });
                         foreach (string line in massbuff)
                         {
                             if (line == textBox1.Text)
                             {
                                 count++;
                             }
                         }

                     }
                 }
             }
             return count;
         }*/

    }
}