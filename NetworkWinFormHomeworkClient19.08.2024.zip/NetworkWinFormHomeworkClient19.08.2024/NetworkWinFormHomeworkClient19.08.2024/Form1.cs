using System.Net.Sockets;
using System.Text;
using System.Windows.Forms;

namespace NetworkWinFormHomeworkClient19._08._2024
{
    public partial class Form1 : Form
    {
        static Socket client;
       static int id;
        static bool startflag = true;

        static int[] rgb = new int[3];
        
        public Form1()
        {
            InitializeComponent();



        }
        public static Tuple<string, int, int, int> ReceiveMessage()
        {
            
            byte[] buffer = new byte[7000];
            byte[] buffer2 = new byte[1];
            byte[] buffer3 = new byte[1];
            byte[] buffer4 = new byte[1];
            int bytesRead;
            try
            {
                lock (client)
                {
                    bytesRead = client.Receive(buffer);
                    string message = System.Text.Encoding.ASCII.GetString(buffer, 0, bytesRead);
                 
                    bytesRead = client.Receive(buffer2);
                    int message2 = buffer2[0];
                    bytesRead = client.Receive(buffer3);
                    int message3 = buffer3[0];
                    bytesRead = client.Receive(buffer4);
                    int message4 = buffer4[0];
                  

                    if (startflag)
                    {
                        id = Convert.ToInt32(message[message.Length - 1]);
                        id -= 48;
                        rgb[0] = message2;
                        rgb[1] = message3;
                        rgb[2] = message4;
                        startflag = false;
                    }
                    return new Tuple<string, int, int, int>(message, message2, message3, message4);
                }
            }
            catch (SocketException ex) { MessageBox.Show(ex.Message); }
            return new Tuple<string, int, int, int>("", 0, 0, 0);
        }
        public static async Task SendMessage(string message)
        {
            // MessageBox.Show(message);
            
            client.Send(Encoding.ASCII.GetBytes(message));

        }


        
        private async void buttonConnect_Click(object sender, EventArgs e)
        {
            client = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            try
            {
                client.Connect((string)textBoxIp.Text, Convert.ToInt32(textBoxPort.Text));
                listView1.Items.Add("Connect to SERVER");
                (sender as Button).Enabled = false;
            }
            catch (SocketException ex)
            {
                listView1.ForeColor = Color.Red;
                listView1.Items.Add(ex.Message);
                client.Close();

            }
           
            Task.Run(() =>
            {
                try
                {
                  
                    while (true)
                    {
                        
                        Tuple<string, int, int, int> tuple = ReceiveMessage();
                       
                        if (tuple.Item1.Contains('\n'))
                        {
                            string[] mess = tuple.Item1.Split('\n');
                            foreach (string m in mess)
                            {
                                listView1.Items.Add(m);
                                int index = listView1.Items.Count - 1;
                                listView1.Items[index].ForeColor = Color.FromArgb(tuple.Item2,tuple.Item3,tuple.Item4);
                            }
                        }
                        else {
                            listView1.Items.Add(tuple.Item1);
                            listView1.Items[listView1.Items.Count - 1].ForeColor = Color.FromArgb(tuple.Item2, tuple.Item3, tuple.Item4);
                        }



                    }
                }
                catch
                {
                    client.Close();
                }
            }

            );

        }

        private async void buttonSend_Click(object sender, EventArgs e)
        {
            //  if(!buttonConnect.Enabled)
            await SendMessage(textBoxMessage.Text);

            if (textBoxMessage.Text.Contains('\n'))
            {
                string[] mess = textBoxMessage.Text.Split('\n');
                bool flag = true;
                foreach (string m in mess)
                {
                    if (flag)
                    {
                        listView1.Items.Add(String.Format($"client {id}(me) :{m}"));
                        listView1.Items[listView1.Items.Count - 1].ForeColor = Color.FromArgb(rgb[0], rgb[1], rgb[2]);
                        flag = false;
                    }
                    else
                    {
                        listView1.Items.Add(String.Format($"{m}"));
                        listView1.Items[listView1.Items.Count - 1].ForeColor = Color.FromArgb(rgb[0], rgb[1], rgb[2]);
                    }
                }
            }
            else {
                listView1.Items.Add(String.Format($"client {id}(me) :{textBoxMessage.Text}"));
                listView1.Items[listView1.Items.Count - 1].ForeColor = Color.FromArgb(rgb[0], rgb[1], rgb[2]);

            }
            }
    }
}