using System.Collections.Specialized;
using System.Data.SqlTypes;
using System.Reflection.Metadata.Ecma335;
namespace ThreadWinFormHomework16._07._2024
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        char c1 = '.';
        char c2 = ' ';
        char c3 = '?';
        char c4 = '!';
        int a1 = 0, a2 = 0, a3 = 0, a4 = 0;
        private async void button1_Click(object sender, EventArgs e)
        {

        }

        private async void button2_Click(object sender, EventArgs e)
        {
            await func();




        }

        public async Task
       func()
        {
            string s = richTextBox1.Text;
            Func<char, int> search = c =>
            {
                int count = 0;
                for (int i = 0; i < s.Length; i++)
                {
                    if (i != 0 && s[i] == c)
                    {
                        char[] chars = { '.', '?', '!' };
                        int cur = 0;
                        foreach (char f in chars)
                            if (s[i - 1] == f)
                                cur++;
                        if (cur == 0)
                            count++;
                    }

                }

                return count;
            };
            Func<char, int> search2 = c =>
            {
                int count = 0;
                for (int i = 0; i < s.Length; i++)
                {
                    if (i != 0 && i != s.Length - 1 && s[i] == c)
                    {
                        char[] chars = { '.', '?', '!', ' ' };
                        int cur = 0;
                        foreach (char f in chars)
                            if (s[i + 1] == f)
                                cur++;
                        if (cur == 0)
                        {
                            if (i + 2 != s.Length)
                            {
                                if (char.IsLetter(s[i + 2]))
                                    count++;
                            }

                        }
                    }

                }
                if (s.Length > 1)
                    count++;
                return count;
            };





            Task task = new Task(() =>
            {
                listBox1.Invoke(new Action(() =>
                {
                    if (listBox1.Items.Count > 0)
                    {
                        listBox1.Items.Clear();
                    }

                    listBox1.Items.Add($"Sentence:{a1.ToString()}");
                    listBox1.Items.Add($"Words:{a2.ToString()}");
                    listBox1.Items.Add($"SentenceWith????:{a3.ToString()}");
                    listBox1.Items.Add($"SentenceWith!!!!!:{a4.ToString()}");
                }));
            });

            Task task1 = Task.Run(() =>
            {



                a1 = search(c1);

            });
            Task task2 = Task.Run(() => { a2 = search2(c2); });
            Task task3 = Task.Run(() =>
            {



                a3 = search(c3);

            }); Task task4 = Task.Run(() =>
            {



                a4 = search(c4);

            });
            Task res = Task.WhenAll(task1, task2, task3, task4).ContinueWith(t =>
            {
                task.Start();


            });
            res.Wait();
        }


        public async Task
       func(bool flag)
        {
            string s = richTextBox1.Text;
            Func<char, int> search = c =>
            {
                int count = 0;
                for (int i = 0; i < s.Length; i++)
                {
                    if (i != 0 && s[i] == c)
                    {
                        char[] chars = { '.', '?', '!' };
                        int cur = 0;
                        foreach (char f in chars)
                            if (s[i - 1] == f)
                                cur++;
                        if (cur == 0)
                            count++;
                    }

                }

                return count;
            };
            Func<char, int> search2 = c =>
            {
                int count = 0;
                for (int i = 0; i < s.Length; i++)
                {
                    if (i != 0 && i != s.Length - 1 && s[i] == c)
                    {
                        char[] chars = { '.', '?', '!', ' ' };
                        int cur = 0;
                        foreach (char f in chars)
                            if (s[i + 1] == f)
                                cur++;
                        if (cur == 0)
                        {
                            if (i + 2 != s.Length)
                            {
                                if (char.IsLetter(s[i + 2]))
                                    count++;
                            }

                        }
                    }

                }
                if (s.Length > 1)
                    count++;
                return count;
            };






            Task task1 = Task.Run(() =>
            {



                a1 = search(c1);

            });
            Task task2 = Task.Run(() => { a2 = search2(c2); });
            Task task3 = Task.Run(() =>
            {



                a3 = search(c3);

            }); Task task4 = Task.Run(() =>
            {



                a4 = search(c4);

            });
            Task res = Task.WhenAll(task1, task2, task3, task4);
            res.Wait();
            using (FileStream fileStream = new FileStream("file.txt", FileMode.Create))
            {
                using (StreamWriter sw = new StreamWriter(fileStream))
                {

                    sw.WriteLineAsync($"Sentence:{a1.ToString()} Words:{a2.ToString()}   SentenceWith????:{a3.ToString()}   SentenceWith!!!!!:{a4.ToString()}  ");
                }
            }
        }


        private async void button3_Click(object sender, EventArgs e)
        {
            await func(true);
          
            

            
        }

        /* public async Task func()
         {
             string s = richTextBox1.Text;
             Func<char, int> search = c =>
             {
                 int count = 0;
                 for (int j = 0; j < s.Length; j++)
                 {

                     if (s[j] == c)
                     {
                         if (c == c2)
                         {
                             // Check if the space is not at the beginning or end of the string
                             if (j > 0 && j < s.Length - 1)
                             {
                                 // Check if the previous character is not a space
                                 if (s[j - 1] != c2)
                                 {
                                     count++;
                                 }
                             }
                         }
                         else
                         {
                             count++;
                         }
                     }
                 }
                 return count;
             };
             a1 = search(c1);
             a2 = search(c2);
             a3 = search(c3);
             a4 = search(c4);
         }*/
    }
}