﻿using System;
using System.Collections.Immutable;
using System.Net;
using System.Net.Sockets;
using System.Reflection.PortableExecutable;
using System.Text;
using static System.Net.Mime.MediaTypeNames;
namespace ConsoleAppUDPServer
{
    class user
    {
        internal string? path;
        internal EndPoint? endPoint;
        internal string message = "";
        internal bool isonlymessage = false;
        internal List<string> messages = new List<string>();    
    }
    class UDP_Server
    {
        public static UdpClient? server;
        
      static  void Filewrite(IPEndPoint point, string message)
        {
            File.AppendAllText($"{point.Address}_{point.Port}.txt", message+$"   {DateTime.Now.ToLongTimeString()} ");
            File.AppendAllText($"{point.Address}_{point.Port}.txt", "\n");
           
          
        }
        static void Filewrite2(IPEndPoint point, string message)
        {
          
            using (
                FileStream file = new FileStream($"{point.Address}_{point.Port}2.txt", FileMode.OpenOrCreate))
            {
                string line;
                int count = 0;
                long lineNumber = 0;
                using (StreamReader reader = new StreamReader(file))
                {
                   
             
                    bool Isnotexist = true;

                  
                    while ((line = reader.ReadLine()) != null)
                    {
                     /*   if (line =="\n")
                            article = 0;*/
                        if (line.Substring(0,line.Length-2) ==message)
                        {
                            Isnotexist = false;

                            count = Convert.ToInt32( line.Substring(line.Length-1));
                            count++;
                            file.Seek(lineNumber, SeekOrigin.Begin);
                            using (StreamWriter writer = new StreamWriter(file))
                            {
                                writer.Write($"{message}:{count}\r\n");
                            }
                            break;
                        }
                        lineNumber += line.Length + 2;
                      
                    }
                    if (Isnotexist)
                    {
                        using (StreamWriter writer = new StreamWriter(file))
                        {
                            if(lineNumber ==0)
                              writer.Write(DateTime.Now.ToString()+"\r\n");
                            writer.Write($"{message}:{++count}\r\n");
                        }
                    }
                }
            }
            

        }

        static bool firstlooping = true;


        public static void StartServer(List<user> users)
        {
            server = new UdpClient(80);

            IPEndPoint point = new IPEndPoint(IPAddress.Any, 80);
            Console.WriteLine("Server started...");

            HttpListener listener = new HttpListener();
            listener.Prefixes.Add("http://127.0.0.1:8080/");
            listener.Start();



            string currhtml = "<html><body><h1>UDP Server Messages</h1>";
            string htmlend = "</body></html>";

            Task.Run(() =>
            {
                try
                {
                    while (true)
                    {
                        Thread.Sleep(5);
                        Mutex mutex = new Mutex();
                        mutex.WaitOne();
                        HttpListenerContext context = listener.GetContext();
                        HttpListenerResponse response = context.Response;
                        string message = "";
                        string currel = "";
                        string message2 = "";
                        List<string>used = new List<string>();
                        List<string >messages = new List<string>(); 

                        
                        for (int i = 0; i < users.Count; i++)
                        {
                            string it = i.ToString();
                            currhtml += $"<p>{{message{it}}}</p>";
                        }
                        foreach (user user in users)
                        {
                            int[] mass = new int[user.messages.Count];
                            mass = mass.Select(x => x = 0).ToArray();
                            for (int i = 0; i < mass.Length; i++)
                            {
                                currel = user.messages[i].ToString();
                                bool flag = true;
                                foreach(string item in used)
                                {
                                    if(currel.Equals(item)) 
                                        flag = false;
                                }
                                if (flag)
                                {
                                    for (int j = 0; j < mass.Length; j++)
                                    {
                                        if (currel.Equals(user.messages[j]))
                                        {
                                            mass[i]++;
                                        }
                                    }
                                    message2 += String.Format($"{currel}:{mass[i]}");
                                    message2 += ' ';
                                    used.Add(currel);
                                 
                                }
                              
                            }
                            
                            /*for (int i = 0; i < user.message.Length; i++)
                            {
                                message += user.messages[i] += "\n";
                            }*/

                            message += string.Format($"{(user.endPoint as IPEndPoint).Address}_{(user.endPoint as IPEndPoint).Port} {DateTime.Now} {message2}");
                            message += user.message;
                            messages.Add(message);
                            message2 = "";
                            message = "";
                            used.Clear();
                        }

                    
                        for (int i = 0; i < messages.Count; i++) {
                            string it = i.ToString();
                            currhtml = currhtml.Replace($"{{message{it}}}", messages[i]);
                         }
                        currhtml += htmlend;

                        byte[] buffer2 = Encoding.UTF8.GetBytes(currhtml);
                        response.ContentLength64 = buffer2.Length;
                        Stream output = response.OutputStream;
                        output.Write(buffer2, 0, buffer2.Length);
                        output.Flush();
                        output.Close();
                        mutex.ReleaseMutex();
                        currhtml = "<html><body><h1>UDP Server Messages</h1>";
                        htmlend = "</body></html>";
                    }
                }
                catch
                {
                    listener.Stop();
                }
            });

            while (true)
            {
                byte[] buffer = server.Receive(ref point);
                string message = System.Text.Encoding.ASCII.GetString(buffer);
                Console.WriteLine($"Received: {message} from {point}");


             

            



                if (firstlooping)
                {
                    if (File.Exists($"{point.Address}_{point.Port}.txt"))
                        File.Delete($"{point.Address}_{point.Port}.txt");
                    if (File.Exists($"{point.Address}_{point.Port}2.txt"))
                        File.Delete($"{point.Address}_{point.Port}2.txt");
                    firstlooping = false;

                }

                Mutex mutex = new Mutex();
                mutex.WaitOne();
                if (users.Count == 0)
                {
                    users.Add(new user { path = $"{point.Address}:{point.Port}.txt", endPoint = point, });
                    users[users.Count - 1].message += message;
                    users[users.Count - 1].message += "     ";
                    users[users.Count - 1].message += "     ";
                    users[users.Count - 1].messages.Add(message);


                    Filewrite(point, message);
                    Filewrite2(point, message);

                }
                else
                {
                    bool flag = true;
                    foreach (user user in users)
                    {
                        if (user.endPoint.Equals(point))
                        {
                            flag = false;
                            user.message += message;
                            user.message += "     ";
                            
                            user.messages.Add(message);
                            Filewrite(point, message);
                            Filewrite2(point, message);
                        }

                    }
                    if (flag)
                    {
                        users.Add(new user { path = $"{point.Address}:{point.Port}.txt", endPoint = point });
                        users[users.Count - 1].message += message;
                        users[users.Count - 1].message += "     ";
                        users[users.Count - 1].message += "     ";
                        users[users.Count - 1].messages.Add(message);
                        Filewrite(point, message);
                        Filewrite2(point, message);
                    }

                    
                  
                }
                mutex.ReleaseMutex();
           

            }

        }
    
    }
        internal class Program
        {
            static void Main(string[] args)
            {
                List<user> users = new List<user> { };

                UDP_Server.StartServer(users);


/*
                Task.Run(() =>
                {
                    while (true)
                    {
                        //Thread.Sleep(500);
                        if (users.Count > 0)
                        {
                            for (int i = users.Count - 1; i >= 0; i--)
                            {
                                try
                                {
                                    UDP_Server.server.Send(Encoding.ASCII.GetBytes("d"), (users[i].endPoint as IPEndPoint));
                                }
                                catch
                                {
                                    lock (users[i].path)
                                    {
                                        using (var fileStream = File.AppendText(users[i].path))
                                        {
                                            fileStream.WriteLine(users[i].message);
                                        }
                                    }
                                    users.RemoveAt(i);
                                }
                            }
                        }
                    }
                });*/



            }
        }
    
}