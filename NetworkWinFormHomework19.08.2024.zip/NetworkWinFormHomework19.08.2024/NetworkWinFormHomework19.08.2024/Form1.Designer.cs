﻿namespace NetworkWinFormHomework19._08._2024
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            listViewChat = new ListView();
            listBoxClients = new ListBox();
            SuspendLayout();
            // 
            // listViewChat
            // 
            listViewChat.Location = new Point(12, 23);
            listViewChat.Name = "listViewChat";
            listViewChat.Size = new Size(647, 415);
            listViewChat.TabIndex = 0;
            listViewChat.UseCompatibleStateImageBehavior = false;
            // 
            // listBoxClients
            // 
            listBoxClients.FormattingEnabled = true;
            listBoxClients.ItemHeight = 25;
            listBoxClients.Location = new Point(665, 23);
            listBoxClients.Name = "listBoxClients";
            listBoxClients.Size = new Size(123, 404);
            listBoxClients.TabIndex = 1;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(listBoxClients);
            Controls.Add(listViewChat);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
        }

        #endregion

        private ListView listViewChat;
        private ListBox listBoxClients;
    }
}