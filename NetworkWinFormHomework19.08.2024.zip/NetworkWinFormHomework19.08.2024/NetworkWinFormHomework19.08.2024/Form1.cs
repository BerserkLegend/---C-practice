using System.Net.Sockets;
using System.Net;
using System.Text;

namespace NetworkWinFormHomework19._08._2024
{
    public partial class Form1 : Form
    {
        // ---------------------------
        public class Client
        {
            public static int ID = 1;

            public Socket? socket { get; set; }
            public string? name { get; set; }
            public Color color { get; set; }
            public DateTime? date { get; set; }

            public override string ToString() => $"{name}";
        }

        static List<Client> clients = new List<Client>();
        static Socket? server;

        // ---------------------------
        public Form1()
        {
            InitializeComponent();
            listViewChat.View = View.List;

            try
            {
                StartServer();
            }
            catch
            {
                MessageBox.Show("Some error happenned");
                Application.Exit();
            }
        }

        void StartServer()
        {
            server = new Socket(
                AddressFamily.InterNetwork,
                SocketType.Stream,
                ProtocolType.Tcp);

            server.Bind(new IPEndPoint(IPAddress.Parse("127.0.0.1"), 80));
            server.Listen(10);

            listViewChat.Items.Add("Server started");
            listViewChat.Items[0].ForeColor = Color.BlueViolet;

            Task.Run(WaitForClients);
        }

        void WaitForClients()
        {
            while (true)
            {

                Socket clientSocket = server.Accept();

                Mutex mutex = new Mutex();
                mutex.WaitOne();
                    Client newClient = FillClient(clientSocket);



                    clients.Add(newClient);

                    AddToListBox(newClient);
                mutex.ReleaseMutex();

                    Thread.Sleep(6);
                
                Task.Run(() => ManageClient(newClient));
            }
        }

        void ManageClient(Client client)
        {
            CancellationTokenSource cts = new CancellationTokenSource();
            lock (client)
            {
                client.socket.Send(Encoding.ASCII.GetBytes($"Your color {client.color} Ur id {Client.ID-1}"));
                client.socket.Send(new byte[] { client.color.R });
                client.socket.Send(new byte[] { client.color.G });
                client.socket.Send(new byte[] { client.color.B });
            }
            byte[] buffer = new byte[1024];
            int bytesRead;

            try
            {
                while ((bytesRead = client.socket.Receive(buffer)) > 0)
                {
                 
                    string message =System.Text.Encoding.ASCII.GetString(buffer);
                   //MessageBox.Show(message);
                    AddToListView(client, message);
                    BroadCast(client,message,true);
                 
                }
            }
            catch { }
            finally
            {
                lock (client)
                {
                    
                    clients.Remove(client);
                    listBoxClients.Items.Remove(client);


                    client.socket.Close();
                    AddToListView(client, $"{client.name} disconnected!");
                    BroadCast(client, $"{client.name} disconnected!");
                 
              
                }
                
            }
            cts.Cancel();
           
        }

        void BroadCast(Client client, string message,bool flag = false)
        {
            if (flag)
            {
                message = client.name + " : " + message; 
            }
            byte[] buffer = System.Text.Encoding.ASCII.GetBytes(message);
            
                foreach (Client cl in clients)
                {


                    if (cl.socket != client.socket)
                    {
                        
                        cl.socket.Send(buffer);
                        cl.socket.Send(new byte[] { client.color.R });
                        cl.socket.Send(new byte[] { client.color.G });
                        cl.socket.Send(new byte[] { client.color.B });

                    }

                }
            
        }

        // -------------------------------
        Client FillClient(Socket clientSocket)
        {
            
            
                Client client = new Client();
            lock(client) {
                client.socket = clientSocket;
                client.name = $"Client {Client.ID++}";
                client.date = DateTime.Now;

                Random r = new Random();
                Color color = Color.FromArgb(
                    r.Next(0, 255),
                    r.Next(0, 255),
                    r.Next(0, 255));
                client.color = color;
            }

            return client;
        }

        void AddToListBox(Client client)
        {
            if (InvokeRequired)
            {
                Invoke(AddToListBox, client);
                return;
            }
            listBoxClients.Items.Add(client);
        }

        void AddToListView(Client client, string message)
        {
            if (InvokeRequired)
            {
                Invoke(AddToListView, client, message);
                return;
            }
            if (message.Contains('\n'))
            {
                string[]mess = message.Split('\n');
                foreach(string m in mess)
                {
                    listViewChat.Items.Add(m);
                    int index = listViewChat.Items.Count - 1;
                    listViewChat.Items[index].ForeColor = client.color;
                }
            }
            else
            {
                listViewChat.Items.Add(message);
                int index = listViewChat.Items.Count - 1;
                listViewChat.Items[index].ForeColor = client.color;
            }
            }

    }
}