﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace HomeworkWpf11._01._2024
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        bool langflag = true;
        public MainWindow()
        {
            InitializeComponent();
            
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Text Files | *.txt";
            if (openFileDialog.ShowDialog() == true)
            {
                using(FileStream f =new FileStream(openFileDialog.FileName, FileMode.Open, FileAccess.Read))
                {
                    using(StreamReader sr = new StreamReader(f))
                    {
                        TextRange textRange = new TextRange(richtextbox1.Document.ContentStart, richtextbox1.Document.ContentEnd);
                        textRange.Text = sr.ReadToEnd();
                        this.Title = openFileDialog.FileName;
                    }
                }
            }
        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Text Files | *.txt";
            if(saveFileDialog.ShowDialog() == true)
            {
                using (FileStream f = new FileStream(saveFileDialog.FileName,FileMode.Create))
                {
                    using(StreamWriter sw = new StreamWriter(f))
                    {
                        TextRange textRange = new TextRange(richtextbox1.Document.ContentStart, richtextbox1.Document.ContentEnd);
                        sw.Write(textRange.Text);
                    }
                }
            }
        }

        private void MenuItem_Click_2(object sender, RoutedEventArgs e)
        {
            if (langflag)
            {
                Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo("uk");
            }
            else
            {
                Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo("en");
            }

            filemenu.Header = Resourse1.Filestr;
            openmenu.Header = Resourse1.Openstr;
            savemenu.Header = Resourse1.Savestr;
            langmenu.Header = Resourse1.Lang;
            textBlock.Text = Resourse1.textblock;

            langflag = !langflag; 

           
        }

        private void Window_Activated(object sender, EventArgs e)
        {
            filemenu.Header = Resourse1.Filestr;
            openmenu.Header = Resourse1.Openstr;
            savemenu.Header = Resourse1.Savestr;
            langmenu.Header = Resourse1.Lang;
            textBlock.Text = Resourse1.textblock;
            langflag = true;
        }
    }
}
