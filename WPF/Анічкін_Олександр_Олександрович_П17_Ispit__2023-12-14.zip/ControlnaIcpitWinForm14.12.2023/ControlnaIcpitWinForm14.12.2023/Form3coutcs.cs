﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ControlnaIcpitWinForm14._12._2023
{
    public partial class Form3coutcs : Form
    {
        public Form3coutcs()
        {
            InitializeComponent();
        }

        /*private void vScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            int scrollValue = vScrollBar1.Value;
            this.VerticalScroll.Value += scrollValue;
            this.Invalidate();
        }*/

    }
}
