﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace IcpitFinal18._01._2024Wpf
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private bool _enflag;
        public MainWindow()
        {
            

            InitializeComponent();
            comboBoxPalivo.Items.Add("Бензин A-95");
            comboBoxPalivo.Items.Add("Бензин A-76");
            comboBoxPalivo.Items.Add("Дизпаливо");
            comboBoxPalivo.SelectedIndex = 0;
            palivocostTextBlock.Text = "54,50";
            



        }

        private void comboBoxPalivo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
           // string[] mass = { "Бензин A-95" , "Бензин A-76", "Дизпаливо" };
            switch(comboBoxPalivo.SelectedIndex)
            {
                case 0:
                    palivocostTextBlock.Text = "54,50";
                    break;
                case 1:
                    palivocostTextBlock.Text = "52,00";
                    break;
                case 2:
                    palivocostTextBlock.Text = "55,80";
                    break;

            }
            if (!string.IsNullOrWhiteSpace(litrTextBox.Text))
            {
                res1update();
            }
        }

        private void RadioButton_Checked(object sender, RoutedEventArgs e)
        {
            litrTextBox.IsReadOnly= false;
            doplatitforgasTextBox.IsReadOnly= true;
            doplatitforgasTextBox.Text = "";
            res1TextBlock.Text = "";
            litrTextBox.Focus();

        }

        private void RadioButton_Checked_1(object sender, RoutedEventArgs e)
        {
            litrTextBox.IsReadOnly = true;
            doplatitforgasTextBox.IsReadOnly = false;
            litrTextBox.Text = "";
            res1TextBlock.Text = "";
            doplatitforgasTextBox.Focus();
        }

        private void litrTextBox_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            
            if (e.Key == Key.Enter)
            {
                res1update();
            }
        }

       

        private void doplatitforgasTextBox_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                double res;
                bool flag = double.TryParse(doplatitforgasTextBox.Text, out res);
                if (flag)
                    res1TextBlock.Text = res.ToString();
            }
        }


        void res1update()
        {
            double value;
            double gas = Convert.ToDouble(palivocostTextBlock.Text);
            bool flag = double.TryParse(litrTextBox.Text, out value);
            if (flag)
            {
                double res = value * gas;
                res1TextBlock.Text = res.ToString();
            }
        }
        void res2update(TextBox a, TextBox b)
        {
            //код проверки
            double value1;
            double value2;

            bool flag = double.TryParse(a.Text, out value1);
            bool flag2 = double.TryParse(b.Text, out value2);
            if (flag && flag2)
            {
                int count = Convert.ToInt32(b.Text);
                int value = Convert.ToInt32(a.Text);
                value *= count;
                int res = Convert.ToInt32(res2TextBlock.Text);
                res -= value;
                res2TextBlock.Text = res.ToString();
            }
        }
       
        private void cafe0countTxtBox_KeyDown(object sender, KeyEventArgs e)
        {
            if(Key.Enter == e.Key)
            {
                int value0=0,value1=0,value2 =0,value3 =0;
                if (!string.IsNullOrWhiteSpace(cafe0countTxtBox.Text))
                {
                    value0 = (Convert.ToInt32(cafe0countTxtBox.Text)) *100;
                    
                }
                if (!string.IsNullOrWhiteSpace(cafe1countTxtBox.Text))
                {
                    value1 = (Convert.ToInt32(cafe1countTxtBox.Text)) * 150;

                }
                if (!string.IsNullOrWhiteSpace(cafe2countTxtBox.Text))
                {
                    value2 = (Convert.ToInt32(cafe2countTxtBox.Text)) * 80;

                }
                if (!string.IsNullOrWhiteSpace(cafe3countTxtBox.Text))
                {
                    value3 = (Convert.ToInt32(cafe3countTxtBox.Text)) * 120;

                }

                int res = value0+value1+value2+value3;

                res2TextBlock.Text = res.ToString();
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            litrTextBox.Text = string.Empty;
            doplatitforgasTextBox.Text = string.Empty;
            /*cafe0countTxtBox.Text = string.Empty;
            cafe1countTxtBox.Text= string.Empty;
            cafe2countTxtBox.Text=string.Empty;
            cafe3countTxtBox.Text = string.Empty;*/
            check0.IsChecked= false;
            check1.IsChecked= false;
            check2.IsChecked= false;
            check3.IsChecked= false;
            res1TextBlock.Text = "0";
            res2TextBlock.Text= "0";
            res3TextBlock.Text= "0";
            
        }



        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {

            cafe0countTxtBox.Text = "0";
            cafe0countTxtBox.IsReadOnly = false;
            cafe0countTxtBox.Focus();
        }
        private void CheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            res2update(cafe0countTxtBox, cafe0costTxtBox);
            cafe0countTxtBox.Text = "";
            cafe0countTxtBox.IsReadOnly = true;

        }
        private void CheckBox_Checked_1(object sender, RoutedEventArgs e)
        {
            cafe1countTxtBox.Text = "0";
            cafe1countTxtBox.IsReadOnly = false;
            cafe1countTxtBox.Focus();
        }

        private void CheckBox_Unchecked_1(object sender, RoutedEventArgs e)
        {
            res2update(cafe1countTxtBox, cafe1costTxtBox);
            cafe1countTxtBox.Text = "";
            cafe1countTxtBox.IsReadOnly = true;
        }

        private void CheckBox_Checked_2(object sender, RoutedEventArgs e)
        {
            cafe2countTxtBox.Text = "0";
            cafe2countTxtBox.IsReadOnly = false;
            cafe2countTxtBox.Focus();
        }

        private void CheckBox_Unchecked_2(object sender, RoutedEventArgs e)
        {
            res2update(cafe2countTxtBox, cafe2costTxtBox);
            cafe2countTxtBox.Text = "";
            cafe2countTxtBox.IsReadOnly = true;
        }

        private void CheckBox_Checked_3(object sender, RoutedEventArgs e)
        {
            cafe3countTxtBox.Text = "0";
            cafe3countTxtBox.IsReadOnly = false;
            cafe3countTxtBox.Focus();
        }

        private void CheckBox_Unchecked_3(object sender, RoutedEventArgs e)
        {
            res2update(cafe3countTxtBox, cafe3costTxtBox);
            cafe3countTxtBox.Text = "";
            cafe3countTxtBox.IsReadOnly = true;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            double value1 = Convert.ToDouble(res1TextBlock.Text);
            double value2 = Convert.ToDouble(res2TextBlock.Text);
            res3TextBlock.Text = (value1 + value2).ToString();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            if(!_enflag)
            {
                Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo("en");
                _enflag = true;
            }
            else
            {
                Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo("uk");
                _enflag = false;
            }
            labelcostfortrans.Content = Resource1.CostText;
            labelGasfortrans.Content = Resource1.GasValue;
            groupboxfortrans.Header = Resource1.Gasstationvalue;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo("uk");
            labelcostfortrans.Content = Resource1.CostText;
            labelGasfortrans.Content = Resource1.GasValue;
            groupboxfortrans.Header = Resource1.Gasstationvalue;
            _enflag = false;
        }
    }
}
