﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace HomeworkWpf9._01._2024
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if(listBox.Items.IsEmpty && comboBox.Items.IsEmpty)
            { listBox.Items.Clear(); 
             comboBox.Items.Clear(); }
            if(!string.IsNullOrEmpty(textboxmin.Text)&& !string.IsNullOrEmpty(textboxmax.Text)&& !string.IsNullOrEmpty(textboxn.Text))
            {
                int n = Convert.ToInt32(textboxn.Text);
                int min = Convert.ToInt32(textboxmin.Text);
                int max = Convert.ToInt32(textboxmax.Text);
                int[] buff = new int[n];
                Random rnd = new Random();
                for(int i =0; i < n; i++)
                {
                    buff[i] = rnd.Next(min,max);
                }
                comboBox.SelectedIndex = 0;
                foreach(int i in buff)
                comboBox.Items.Add(i);
                foreach(int i in buff)
                listBox.Items.Add(i);
                
            }
        }
    }
}
