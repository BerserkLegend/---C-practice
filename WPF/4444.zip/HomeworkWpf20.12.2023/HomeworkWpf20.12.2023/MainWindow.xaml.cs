﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace HomeworkWpf20._12._2023
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            
            string mess = sender.ToString();
            mess =mess.Substring(mess.Length - 1);
            textbox1.Text = (textbox1.Text.Length == 1 && textbox1.Text =="0") ? mess : textbox1.Text + mess;

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            textbox1.Text = "0";
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            string mess = sender.ToString();
            mess = mess.Substring(mess.Length - 1);
            textbox2.Text = (textbox2.Text.Length == 1 && textbox2.Text == "0") ? mess : textbox2.Text + mess;
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            textbox2.Text = "0";
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(textbox1.Text) && !string.IsNullOrEmpty(textbox1.Text))
            {
                int res =0;
                string mess = sender.ToString();
                mess = mess.Substring(mess.Length - 1);
                
                switch (mess)
                {
                    
                    case "+":
                        res=Convert.ToInt32(textbox1.Text)+Convert.ToInt32(textbox2.Text);
                        break;
                    case "-":
                        res = Convert.ToInt32(textbox1.Text) - Convert.ToInt32(textbox2.Text);
                        break;
                    case "*":
                        res = Convert.ToInt32(textbox1.Text) * Convert.ToInt32(textbox2.Text);
                        break;
                    case "/":
                        res = Convert.ToInt32(textbox1.Text) / Convert.ToInt32(textbox2.Text);
                        break;


                }
                textblock1.Text = $"Результат: { textbox1.Text} {mess} {textbox2.Text} = {res}";

            }
        }
    }
}
