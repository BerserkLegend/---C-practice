﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HomeworkWinForm12._12._2023
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            //Graphics graphics = e.Graphics;
            Pen pen = new Pen(Color.Aqua,5);
            Pen pen2 = new Pen(Color.Aqua);
            e.Graphics.DrawLine(pen,0,0,0,500);
            e.Graphics.DrawLine(pen, 0, 0, 600, 0);
            e.Graphics.DrawLine(pen, 600, 0, 600, 500);
            e.Graphics.DrawLine(pen, 0, 370, 600, 370);


            int horizontal = 53;
            int vertical = 53;
            for(int i = 1; i<8; i++)
              e.Graphics.DrawLine(pen2, 0, horizontal*i, 600, horizontal * i);

            for (int i = 1; i < 8; i++)
                e.Graphics.DrawLine(pen2, vertical*i, 0, vertical * i, 500);
            SolidBrush blueBrush = new SolidBrush(Color.Blue);


            int x1 =10, y1=12,per =30;
            int x2 = x1, y2 = 223;
            e.Graphics.FillEllipse(blueBrush, new Rectangle(x1, y1, 30, 30));
            e.Graphics.DrawEllipse(pen, new Rectangle(x1, y1, 30, 30));

            
            e.Graphics.FillEllipse(blueBrush, new Rectangle((x1 - 1 + per) * 3, y1, 30, 30));
            e.Graphics.DrawEllipse(pen, new Rectangle((x1- 1 + per) * 3, y1, 30, 30));

            e.Graphics.FillEllipse(blueBrush, new Rectangle((x1 - 3 + per) * 6, y1, 30, 30));
            e.Graphics.DrawEllipse(pen, new Rectangle((x1 - 3 + per) * 6, y1, 30, 30));
           
            e.Graphics.FillEllipse(blueBrush, new Rectangle((x1+1 + per) * 8, y1, 30, 30));
            e.Graphics.DrawEllipse(pen, new Rectangle((x1+1 + per) * 8, y1, 30, 30));


            e.Graphics.FillEllipse(blueBrush, new Rectangle((x1 - 1 + per-6) * 2 ,(y1+per-10)*2, 30, 30));
            e.Graphics.DrawEllipse(pen, new Rectangle((x1 - 1 + per-6) * 2, (y1 + per-10) * 2, 30, 30));
            
            e.Graphics.FillEllipse(blueBrush, new Rectangle((x1 - 1 + per+3) * 4, (y1 + per - 10) * 2, 30, 30));
            e.Graphics.DrawEllipse(pen, new Rectangle((x1 - 1 + per+3) * 4, (y1 + per - 10) * 2, 30, 30));

            e.Graphics.FillEllipse(blueBrush, new Rectangle((x1 - 1 + per + 7) * 6, (y1 + per - 10) * 2, 30, 30));
            e.Graphics.DrawEllipse(pen, new Rectangle((x1 - 1 + per + 7) * 6, (y1 + per - 10) * 2, 30, 30));





            e.Graphics.FillEllipse(blueBrush, new Rectangle(x1, (y1 + per+17) * 2, 30, 30));
            e.Graphics.DrawEllipse(pen, new Rectangle(x1, (y1 + per + 17) * 2, 30, 30));


            e.Graphics.FillEllipse(blueBrush, new Rectangle((x1 - 1 + per) * 3, (y1 + per + 17) * 2, 30, 30));
            e.Graphics.DrawEllipse(pen, new Rectangle((x1 - 1 + per) * 3, (y1 + per + 17) * 2, 30, 30));

            e.Graphics.FillEllipse(blueBrush, new Rectangle((x1 - 3 + per) * 6, (y1 + per + 17) * 2, 30, 30));
            e.Graphics.DrawEllipse(pen, new Rectangle((x1 - 3 + per) * 6, (y1 + per + 17) * 2, 30, 30));

            e.Graphics.FillEllipse(blueBrush, new Rectangle((x1 + 1 + per) * 8, (y1 + per + 17) * 2, 30, 30));
            e.Graphics.DrawEllipse(pen, new Rectangle((x1 + 1 + per) * 8, (y1 + per + 17) * 2, 30, 30));



           // e.Graphics.FillEllipse(blueBrush, new Rectangle(x2, y2, 30, 30));
            e.Graphics.DrawEllipse(pen, new Rectangle(x2, y2, 30, 30));

          //  e.Graphics.FillEllipse(blueBrush, new Rectangle((x2 - 1 + per) * 3, y2, 30, 30));
            e.Graphics.DrawEllipse(pen, new Rectangle((x2 - 1 + per) * 3, y2, 30, 30));

           // e.Graphics.FillEllipse(blueBrush, new Rectangle((x2 - 3 + per) * 6, y2, 30, 30));
            e.Graphics.DrawEllipse(pen, new Rectangle((x2 - 3 + per) * 6, y2, 30, 30));

          //  e.Graphics.FillEllipse(blueBrush, new Rectangle((x2 + 1 + per) * 8, y2, 30, 30));
            e.Graphics.DrawEllipse(pen, new Rectangle((x2 + 1 + per) * 8, y2, 30, 30));



           // e.Graphics.FillEllipse(blueBrush, new Rectangle((x2 - 1 + per - 6) * 2, y2+54, 30, 30));
            e.Graphics.DrawEllipse(pen, new Rectangle((x2 - 1 + per - 6) * 2, y2+54, 30, 30));

          //  e.Graphics.FillEllipse(blueBrush, new Rectangle((x1 - 1 + per + 3) * 4, y2 + 54, 30, 30));
            e.Graphics.DrawEllipse(pen, new Rectangle((x1 - 1 + per + 3) * 4, y2 + 54, 30, 30));

          //  e.Graphics.FillEllipse(blueBrush, new Rectangle((x1 - 1 + per + 7) * 6, y2 + 54, 30, 30));
            e.Graphics.DrawEllipse(pen, new Rectangle((x1 - 1 + per + 7) * 6, y2 + 54, 30, 30));






           // e.Graphics.FillEllipse(blueBrush, new Rectangle(x2, y2+108, 30, 30));
            e.Graphics.DrawEllipse(pen, new Rectangle(x2, y2+108, 30, 30));

           // e.Graphics.FillEllipse(blueBrush, new Rectangle((x2 - 1 + per) * 3, y2 + 108, 30, 30));
            e.Graphics.DrawEllipse(pen, new Rectangle((x2 - 1 + per) * 3, y2 + 108, 30, 30));

          //  e.Graphics.FillEllipse(blueBrush, new Rectangle((x2 - 3 + per) * 6, y2 + 108, 30, 30));
            e.Graphics.DrawEllipse(pen, new Rectangle((x2 - 3 + per) * 6, y2 + 108, 30, 30));

           // e.Graphics.FillEllipse(blueBrush, new Rectangle((x2 + 1 + per) * 8, y2 + 108, 30, 30));
            e.Graphics.DrawEllipse(pen, new Rectangle((x2 + 1 + per) * 8, y2 + 108, 30, 30));

        }
    }
}
