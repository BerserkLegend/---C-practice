﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Server
{
    internal class Program
    {
        private const string _serverHost = "localhost";
        private const int _serverPort = 1024;
        private static Thread _serverThread;
        static void Main(string[] args)
        {
            _serverThread = new Thread(startServer);
            _serverThread.IsBackground = true;
            _serverThread.Start();
            Console.WriteLine("Commands: \n /getusers - get All users \n /getcountusers - get total count users");
            Console.WriteLine("/kick <username> - disconect user");
            while (true)
            {
                handlerCommands(Console.ReadLine());
            }
        }

        private static void handlerCommands(string cmd)
        {
            cmd = cmd.ToLower();
            if (cmd.Contains("/getusers"))
            { 
                int countUsers = Server.Clients.Count;
                if (countUsers == 0)
                {
                    Console.WriteLine("No users connected :(");
                }
                else
                {
                    for (int i = 0; i < countUsers; i++)
                    {
                        Console.WriteLine("[{0}]: {1}", i, Server.Clients[i].UserName);
                    }
                }
            }
            if (cmd.Contains("/getcountusers"))
            {
                int countUsers = Server.Clients.Count;
                Console.WriteLine("Total users: {0}",countUsers);
            }
            if (cmd.Contains("/kick"))
            {
                string userName = cmd.Substring(cmd.IndexOf(' ') + 1);
                for (int i = 0; i < Server.Clients.Count; i++)
                {
                    if (Server.Clients[i].UserName.ToLower() == userName)
                    {
                        Server.EndClient(Server.Clients[i]);
                        return;
                    }
                }
            }
        }
        private static void startServer()
        {
            IPHostEntry ipHost = Dns.GetHostEntry(_serverHost);
            IPAddress ipAddress = ipHost.AddressList[0];
            IPEndPoint iPEndPoint = new IPEndPoint(ipAddress, _serverPort);
            Socket socket = new Socket(ipAddress.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
            socket.Bind(iPEndPoint);
            socket.Listen(1000);
            Console.WriteLine("Server has been started on IP: {0}.",iPEndPoint);
            while (true)
            {
                try
                {
                    Socket user = socket.Accept();
                    Server.NewClient(user);
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error: {0}",ex.Message);
                }
            }
        }
    }
}
