﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace NetworkHomeworkClient05._08._2024
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int clientId = 0;
            Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
            byte[] buffer = Encoding.ASCII.GetBytes("h");
            socket.SendTo(buffer, new IPEndPoint(IPAddress.Parse("127.0.0.1"), 80));
            byte[] replybufftemp = new byte[1];
            EndPoint remoteEndPoint = new IPEndPoint(IPAddress.Any, 0);
            int bytesRead = socket.ReceiveFrom(replybufftemp, ref remoteEndPoint);
            clientId = replybufftemp[0];
            Console.WriteLine("Connected to server with Id: " + clientId);


            try
            {
                while (true)
                {


                    Task.Run(() =>
                    {
                        Receive(socket, remoteEndPoint);
                    });
                    string answer = Console.ReadLine();
                    socket.SendTo(Encoding.ASCII.GetBytes(answer), remoteEndPoint);


                }
            }
            finally {
       socket.Close(); }
        }

        static void Receive(Socket socket, EndPoint remoteEndPoint)
        {
            
            byte[] replybuff = new byte[255];
            string question = "";

            while (true)
            {
             
                int bytesRead = socket.ReceiveFrom(replybuff, ref remoteEndPoint);
                if (bytesRead > 0)
                {
                    question = Encoding.ASCII.GetString(replybuff, 0, bytesRead);
                    Console.WriteLine( question);
                   
                }
            }
        }
    }
}