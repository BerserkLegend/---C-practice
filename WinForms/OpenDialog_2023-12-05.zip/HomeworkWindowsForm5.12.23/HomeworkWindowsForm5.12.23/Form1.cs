﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HomeworkWindowsForm5._12._23
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
            comboBox1.SelectedIndex = 0;
            richTextBox1.Font = new Font("Microsoft Sans Serif", 12);
        }

        private void изменитьШрифтToolStripMenuItem_Click(object sender, EventArgs e)
        {
            switch (comboBox1.SelectedIndex) {
            case 0:
                  richTextBox1.SelectionFont = new Font("Microsoft Sans Serif", 12);
                    break;
                case 1:
                    richTextBox1.SelectionFont = new Font("Microsoft Sans Serif", 14);
                    break;
                case 2:
                    richTextBox1.SelectionFont = new Font("Microsoft Sans Serif", 18);
                    break;
                case 3:
                    richTextBox1.SelectionFont = new Font("Microsoft Sans Serif", 20);
                    break;
                case 4:
                    richTextBox1.SelectionFont = new Font("Microsoft Sans Serif", 30);
                    break;

            }   
        }

        private void змінитиКолірToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.SelectionColor = Color.Red;
        }

        private void изменитьТекстToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = textBox1.Text;
        }
    }
}
