﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HomeworkWinForms7._12._2023
{
    public partial class Form1 : Form
    {
        internal static Control f1;
        public Form1()
        {
           
            InitializeComponent();
        }
        
        private void Form1_Load(object sender, EventArgs e)
        {
            f1 = this;
            string[] arrea = { "Name", "Course", "Mathematic", "Informatic", "Physics" };
            dataGridView1.Rows.Add(arrea[0], "String","Прізвище та імя студента");
            dataGridView1.Rows.Add(arrea[1], "Int", "Курс навчання");
            dataGridView1.Rows.Add(arrea[2], "Int", "Оцінка з математики");
            dataGridView1.Rows.Add(arrea[3], "Int", "Оцінка з информатики");
            dataGridView1.Rows.Add(arrea[4], "Int", "Оцінка з фізики");

              for(int i =2; i < arrea.Length; i++)
                listBox1.Items.Add(arrea[i]);


            

        }

        private void добавитиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            if (f2.ShowDialog() == DialogResult.OK)
            {
                DataColumn data = new DataColumn();
                data.ColumnName = (dataGridView2.Columns[dataGridView2.ColumnCount - 1]).HeaderText;
                
                dataGridView2.Columns.RemoveAt(dataGridView2.ColumnCount - 1);

              
                dataGridView2.Columns.Add($"ColumnName{dataGridView2.ColumnCount}",f2.textBox1.Text);
                dataGridView2.Columns.Add($"ColumnName{dataGridView2.ColumnCount}", data.ColumnName);

                listBox1.Items.Add(dataGridView2.Columns[dataGridView2.ColumnCount - 2].HeaderText);

                dataGridView1.Rows.Add(f2.textBox1.Text, "Int", $"Оцінка з {f2.textBox2.Text}");


            }
        }

        private void видалитиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dataGridView2.CurrentRow != null)
            {
                if (MessageBox.Show("Вы действительно хотите удалить?", "Удаление", MessageBoxButtons.OKCancel) == DialogResult.OK && dataGridView2.Rows.Count-1 != dataGridView2.CurrentRow.Index)
                    dataGridView2.Rows.RemoveAt(dataGridView2.CurrentRow.Index);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(!string.IsNullOrEmpty(textBox1.Text))
            {
                dataGridView2.Columns[listBox1.SelectedIndex+2].HeaderText = textBox1.Text;
                dataGridView1.Rows[listBox1.SelectedIndex + 2].Cells[0].Value = textBox1.Text;
                listBox1.Items[listBox1.SelectedIndex] = textBox1.Text;
               
            }
        }

        private void видалитиЗаписпредметToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Вы действительно хотите удалить?", "Удаление", MessageBoxButtons.OKCancel) == DialogResult.OK)
            {
                if (listBox1.Items[listBox1.SelectedIndex] == dataGridView2.Columns[listBox1.SelectedIndex+2].HeaderText)
                {
                    dataGridView2.Columns.RemoveAt(listBox1.SelectedIndex + 2);
                    dataGridView1.Rows.RemoveAt(listBox1.SelectedIndex + 2);
                    listBox1.Items.RemoveAt(listBox1.SelectedIndex);
                }
                dataGridView2.CellEndEdit += new DataGridViewCellEventHandler(dataGridView2_CellEndEdit);
                MEGAFUNC();

            }
        }

        private void dataGridView2_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            MEGAFUNC();

        
        }
      void MEGAFUNC()
      {
        bool flag = true;
        for (int i = 0; i < dataGridView2.Rows[dataGridView2.Rows.Count - 2].Cells.Count - 1; i++)
        {
            if (string.IsNullOrEmpty((string)dataGridView2.Rows[dataGridView2.Rows.Count - 2].Cells[i].Value))
            {
                flag = false;
            }
        }
        if (flag)
        {
            double result = Convert.ToDouble(dataGridView2.Rows[dataGridView2.Rows.Count - 2].Cells[2].Value);
            int delitel = 1;

            for (int i = 3; i < dataGridView2.Rows[dataGridView2.Rows.Count - 2].Cells.Count - 1; i++)
            {
                delitel++;

                result += Convert.ToDouble(dataGridView2.Rows[dataGridView2.Rows.Count - 2].Cells[i].Value);


            }
            dataGridView2.Rows[dataGridView2.Rows.Count - 2].Cells[dataGridView2.Rows[dataGridView2.Rows.Count - 2].Cells.Count - 1].Value = (Math.Round(result /= delitel, 2)).ToString();

           


        }
        
      }

        private void button2_Click(object sender, EventArgs e)
        {
            Show();
        }
        void Show()
        {
            double[] minmax = MaxMin();
            MessageBox.Show((dataGridView2.CurrentRow.Cells[dataGridView2.ColumnCount - 1].Value).ToString());
            MessageBox.Show($"max:{minmax[0].ToString()} min:{minmax[1].ToString()}");

        }
        double[] MaxMin()
        {
            double min = Convert.ToDouble(dataGridView2.Rows[dataGridView2.Rows.Count - 2].Cells[2].Value);
            double max = Convert.ToDouble(dataGridView2.Rows[dataGridView2.Rows.Count - 2].Cells[2].Value);
            for (int i = 3; i < dataGridView2.Rows[dataGridView2.Rows.Count - 2].Cells.Count - 1; i++)
            {

                if (max < Convert.ToDouble(dataGridView2.Rows[dataGridView2.Rows.Count - 2].Cells[i].Value))
                {
                    max = Convert.ToDouble(dataGridView2.Rows[dataGridView2.Rows.Count - 2].Cells[i].Value);
                }
                else if (min > Convert.ToDouble(dataGridView2.Rows[dataGridView2.Rows.Count - 2].Cells[i].Value))
                {
                    min = Convert.ToDouble(dataGridView2.Rows[dataGridView2.Rows.Count - 2].Cells[i].Value);
                }
            }
            return new double[] { min, max };

        }
    }
}
