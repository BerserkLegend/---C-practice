﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HomeworkC_WinForm16._11._23
{
    public partial class Form1 : Form
    {
        





        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            System.Drawing.Drawing2D.GraphicsPath gp = new System.Drawing.Drawing2D.GraphicsPath();
            Point[] point = new Point[3];
            point[0] = new Point(0, 0);
            point[1] = new Point(0, 200);
            point[2] = new Point(200, 300);
            gp.AddPolygon(point);
            Region rg = new Region(gp);
            this.Region = rg;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }
        /*Timer timer = new Timer();
private void Form1_Load(object sender, EventArgs e)
{

   timer.Interval = 1000;
   timer.Tick += (object sender2, EventArgs e2) =>
   {
       this.BackColor = (this.BackColor == Color.White) ? Color.Black : Color.White;

   };
   timer.Tick += (object sender2, EventArgs e2) =>
   {
       label1.ForeColor = (this.BackColor == Color.White) ? Color.Black : Color.Red;
       label1.Text = (this.BackColor == Color.White) ? "Я ЗНАЮ ТВОЙ СЕКРЕЕЕТ))" : "ТЫ БИБИЗЯНКА))))))))))";
   };

   timer.Start();
}

private void Form1_FormClosing(object sender, FormClosingEventArgs e)
{
   if (timer != null)
   {
       timer.Stop();
       timer.Dispose();
   }
}*/


    }
}
