using System.Net;
using System.Net.Sockets;
using System.Text;

namespace Client
{
    public partial class Form1 : Form
    {
        private delegate void printer(string data);
        private delegate void cleaner();
        printer Printer;
        cleaner Cleaner;
        private Socket _serverSocket;
        private Thread _clientThread;
        private string _serverHost;
        private int _serverPort;
        public Form1()
        {
            InitializeComponent();
        }

        private void listner()
        {
            while (_serverSocket.Connected)
            {
                try
                {
                    byte[] buffer = new byte[8192];
                    int bytesRec = _serverSocket.Receive(buffer);
                    string data = Encoding.UTF8.GetString(buffer, 0, bytesRec);
                    if (data.Contains("#updatechat"))
                    {
                        UpdateChat(data);
                        continue;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "�������", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }

        private void UpdateChat(string data)
        {
            clearChat();
            string[] messages = data.Split('&')[1].Split('|');
            int countMessages = messages.Length;
            if (countMessages <= 0) return;
            for (int i = 0; i < countMessages; i++)
            {
                try
                {
                    if (string.IsNullOrEmpty(messages[i])) continue;
                    print(String.Format("[{0}]:{1}", messages[i].Split('~')[0], messages[i].Split('~')[1]));
                }
                catch
                {
                    continue;
                }
            }
        }

        private void connect()
        {
            try
            {
                IPHostEntry ipHost = Dns.GetHostEntry(_serverHost);
                IPAddress ipAddress = ipHost.AddressList[0];
                IPEndPoint iPEndPoint = new IPEndPoint(ipAddress, _serverPort);
                _serverSocket = new Socket(ipAddress.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
                _serverSocket.Connect(iPEndPoint);
            }
            catch
            {
                print("������ �����������!!!");
            }
        }

        private void clearChat()
        {
            if (this.InvokeRequired)
            {
                this.Invoke(Cleaner);
                return;
            }
            chatBox.Clear();
        }

        private void print(string data)
        {
            if (this.InvokeRequired)
            {
                this.Invoke(Printer, data); return;
            }
            if (chatBox.Text.Length == 0)
            {
                chatBox.AppendText(data);
            }
            else
            {
                chatBox.AppendText(Environment.NewLine + data);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string Name = userName.Text;
            if (string.IsNullOrEmpty(Name))
            {
                MessageBox.Show("�������", "���� ��\'� ����� (", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            send("#setname&" + Name);
        }

        private void send(string data)
        {
            try
            {
                byte[] buffer = Encoding.UTF8.GetBytes(data);
                int bytesSend = _serverSocket.Send(buffer);
            }
            catch
            {
                print("��\'��� � �������� �������� ������ (");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            sendMessage();
        }

        private void sendMessage()
        {
            try
            {
                string data = chatMessage.Text;
                if (string.IsNullOrEmpty(data)) return;
                send("#newmsg&" + data);
                chatMessage.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("�������", ex.Message, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void chatMessage_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter) sendMessage();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            _serverHost = txt_Server.Text.Trim();
            _serverPort = Convert.ToInt32(txt_Port.Text.Trim());
            Printer = new printer(print);
            Cleaner = new cleaner(clearChat);
            connect();
            _clientThread = new Thread(listner);
            _clientThread.IsBackground = true;
            _clientThread.Start();
            button1.Enabled = true;
        }
    }
}
