﻿namespace Client
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            userName = new TextBox();
            button1 = new Button();
            chatBox = new TextBox();
            chatMessage = new TextBox();
            button2 = new Button();
            label2 = new Label();
            txt_Server = new TextBox();
            txt_Port = new TextBox();
            label3 = new Label();
            label4 = new Label();
            button3 = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 16F);
            label1.Location = new Point(16, 31);
            label1.Name = "label1";
            label1.Size = new Size(109, 30);
            label1.TabIndex = 0;
            label1.Text = "Ваше і'мя";
            // 
            // userName
            // 
            userName.Font = new Font("Segoe UI", 16F);
            userName.Location = new Point(155, 28);
            userName.Name = "userName";
            userName.Size = new Size(473, 36);
            userName.TabIndex = 1;
            // 
            // button1
            // 
            button1.Enabled = false;
            button1.Font = new Font("Segoe UI", 16F);
            button1.Location = new Point(649, 28);
            button1.Name = "button1";
            button1.Size = new Size(115, 36);
            button1.TabIndex = 2;
            button1.Text = "До чату";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // chatBox
            // 
            chatBox.Font = new Font("Segoe UI", 16F);
            chatBox.Location = new Point(16, 160);
            chatBox.Multiline = true;
            chatBox.Name = "chatBox";
            chatBox.ReadOnly = true;
            chatBox.ScrollBars = ScrollBars.Both;
            chatBox.Size = new Size(1133, 374);
            chatBox.TabIndex = 3;
            // 
            // chatMessage
            // 
            chatMessage.Font = new Font("Segoe UI", 16F);
            chatMessage.Location = new Point(16, 567);
            chatMessage.Name = "chatMessage";
            chatMessage.Size = new Size(863, 36);
            chatMessage.TabIndex = 4;
            chatMessage.KeyDown += chatMessage_KeyDown;
            // 
            // button2
            // 
            button2.Font = new Font("Segoe UI", 16F);
            button2.Location = new Point(897, 567);
            button2.Name = "button2";
            button2.Size = new Size(174, 36);
            button2.TabIndex = 5;
            button2.Text = "Відправити";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 16F);
            label2.Location = new Point(16, 118);
            label2.Name = "label2";
            label2.Size = new Size(48, 30);
            label2.TabIndex = 6;
            label2.Text = "Чат";
            // 
            // txt_Server
            // 
            txt_Server.Font = new Font("Segoe UI", 14F);
            txt_Server.Location = new Point(913, 28);
            txt_Server.Name = "txt_Server";
            txt_Server.Size = new Size(206, 32);
            txt_Server.TabIndex = 7;
            txt_Server.Text = "ftl.kherson.ua";
            // 
            // txt_Port
            // 
            txt_Port.Font = new Font("Segoe UI", 14F);
            txt_Port.Location = new Point(913, 80);
            txt_Port.Name = "txt_Port";
            txt_Port.Size = new Size(206, 32);
            txt_Port.TabIndex = 8;
            txt_Port.Text = "1024";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
            label3.Location = new Point(816, 39);
            label3.Name = "label3";
            label3.Size = new Size(70, 25);
            label3.TabIndex = 9;
            label3.Text = "Server";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
            label4.Location = new Point(835, 87);
            label4.Name = "label4";
            label4.Size = new Size(51, 25);
            label4.TabIndex = 10;
            label4.Text = "Port";
            // 
            // button3
            // 
            button3.Font = new Font("Segoe UI", 14F);
            button3.Location = new Point(649, 81);
            button3.Name = "button3";
            button3.Size = new Size(115, 31);
            button3.TabIndex = 11;
            button3.Text = "Connect";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1161, 623);
            Controls.Add(button3);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(txt_Port);
            Controls.Add(txt_Server);
            Controls.Add(label2);
            Controls.Add(button2);
            Controls.Add(chatMessage);
            Controls.Add(chatBox);
            Controls.Add(button1);
            Controls.Add(userName);
            Controls.Add(label1);
            MaximizeBox = false;
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Чат";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox userName;
        private Button button1;
        private TextBox chatBox;
        private TextBox chatMessage;
        private Button button2;
        private Label label2;
        private TextBox txt_Server;
        private TextBox txt_Port;
        private Label label3;
        private Label label4;
        private Button button3;
    }
}
